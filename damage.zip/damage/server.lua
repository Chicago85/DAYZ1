local L0_0
L0_0 = {
  {1, 2},
  {1, 2},
  {
    {1, 2},
    {
      {1, 2},
      {1, 2},
      {1, 2},
      {
        {1, 2},
        {1, 2},
        {1, 2},
        {
          {
            {
              {1, 2}
            }
          }
        }
      }
    },
    {1, 2},
    {1, 2}
  },
  {1, 2}
}
L0_0 = nil
function removeHEXFromString(A0_1)
  return A0_1:gsub("#%x%x%x%x%x%x", "")
end
function fadeGuiElement(A0_2, A1_3)
  if A0_2 and A1_3 then
    if A0_2 == 1 then
      guiSetAlpha(_UPVALUE0_.label[3], 0)
    end
    if A0_2 == 2 then
      guiSetAlpha(_UPVALUE0_.label[4], 0)
    end
    if guiGetAlpha(_UPVALUE0_.label[A0_2]) ~= 0 and A0_2 and A1_3 then
      guiSetAlpha(_UPVALUE0_.label[A0_2], guiGetAlpha(_UPVALUE0_.label[A0_2]) - 0.05)
    elseif isTimer(_UPVALUE1_[A1_3]) then
      killTimer(_UPVALUE1_[A1_3])
      _UPVALUE1_[A1_3] = nil
    end
  end
end
function hideGuiElement(A0_4, A1_5, A2_6)
  if A1_5 == true and A0_4 then
    guiSetAlpha(_UPVALUE0_.label[A0_4], 1)
    if A0_4 == 1 then
      guiSetAlpha(_UPVALUE0_.label[3], 0.8)
    end
    if A0_4 == 2 then
      guiSetAlpha(_UPVALUE0_.label[4], 0.8)
    end
  end
  if A1_5 == false and A0_4 and A2_6 then
    if isTimer(_UPVALUE1_[A2_6]) then
      killTimer(_UPVALUE1_[A2_6])
      _UPVALUE1_[A2_6] = nil
    end
    _UPVALUE1_[A2_6] = setTimer(fadeGuiElement, 50, 0, A0_4, A2_6)
  end
end
addEventHandler("onClientResourceStart", resourceRoot, function()
  _UPVALUE0_.label[3] = guiCreateLabel(0.1012, 0.5212, 0.9, 0.9, "", true)
  _UPVALUE0_.label[4] = guiCreateLabel(0.1012, 0.5612, 0.9, 0.9, "", true)
  _UPVALUE0_.label[1] = guiCreateLabel(0.1, 0.52, 0.9, 0.9, "", true)
  _UPVALUE0_.label[2] = guiCreateLabel(0.1, 0.56, 0.9, 0.9, "", true)
  guiSetEnabled(_UPVALUE0_.label[1], false)
  guiSetEnabled(_UPVALUE0_.label[2], false)
  guiSetEnabled(_UPVALUE0_.label[3], false)
  guiSetEnabled(_UPVALUE0_.label[4], false)
  guiSetAlpha(_UPVALUE0_.label[1], 0)
  guiSetAlpha(_UPVALUE0_.label[2], 0)
  guiSetAlpha(_UPVALUE0_.label[3], 0)
  guiSetAlpha(_UPVALUE0_.label[4], 0)
  guiLabelSetColor(_UPVALUE0_.label[1], 255, 0, 0)
  guiLabelSetColor(_UPVALUE0_.label[2], 0, 255, 0)
  guiLabelSetColor(_UPVALUE0_.label[3], 0, 0, 0)
  guiLabelSetColor(_UPVALUE0_.label[4], 0, 0, 0)
  guiSetFont(_UPVALUE0_.label[1], _UPVALUE0_.font)
  guiSetFont(_UPVALUE0_.label[2], _UPVALUE0_.font)
  guiSetFont(_UPVALUE0_.label[3], _UPVALUE0_.font)
  guiSetFont(_UPVALUE0_.label[4], _UPVALUE0_.font)
end)
addEvent("sendDmgToAttacker", true)
addEventHandler("sendDmgToAttacker", localPlayer, function(A0_7)
  local L1_8, L2_9, L3_10, L4_11, L5_12, L6_13
  L1_8 = A0_7[1]
  L2_9 = A0_7[2]
  L3_10 = A0_7[3]
  L4_11 = A0_7[4]
  L5_12 = A0_7[5]
  L6_13 = "+"
  L6_13 = L6_13 .. math.floor(L1_8) .. " dmg / " .. removeHEXFromString(L2_9) .. " / " .. getWeaponNameFromID(L3_10) .. " / " .. getBodyPartName(L4_11) .. " / " .. math.floor(L5_12) .. "%"
  if isTimer(_UPVALUE0_[2]) then
    killTimer(_UPVALUE0_[2])
    _UPVALUE0_[2] = nil
  end
  guiSetText(_UPVALUE1_.label[2], L6_13)
  guiSetText(_UPVALUE1_.label[4], L6_13)
  hideGuiElement(2, true)
  _UPVALUE0_[2] = setTimer(hideGuiElement, 8000, 1, 2, false, 4)
  --outputConsole("[[ damagescript LOG ]]: +" .. math.floor(L1_8) .. " dmg / " .. removeHEXFromString(L2_9) .. " / " .. getWeaponNameFromID(L3_10) .. " / " .. getBodyPartName(L4_11) .. " / " .. math.floor(L5_12) .. "%")
end)
addEvent("sendDmgToSource", true)
addEventHandler("sendDmgToSource", localPlayer, function(A0_14)
  local L1_15, L2_16, L3_17, L4_18
  L1_15 = A0_14[1]
  L2_16 = A0_14[2]
  L3_17 = A0_14[3]
  L4_18 = "#You've been hit by "
  L4_18 = L4_18 .. removeHEXFromString(L1_15) .. " / " .. getWeaponNameFromID(L2_16) .. " / " .. getBodyPartName(L3_17)
  if isTimer(_UPVALUE0_[1]) then
    killTimer(_UPVALUE0_[1])
    _UPVALUE0_[1] = nil
  end
  guiSetText(_UPVALUE1_.label[1], L4_18)
  guiSetText(_UPVALUE1_.label[3], L4_18)
  hideGuiElement(1, true)
  _UPVALUE0_[1] = setTimer(hideGuiElement, 8000, 1, 1, false, 3)
  --outputConsole("[[ damagescript LOG ]]: #You've been hit by " .. removeHEXFromString(L1_15) .. " / " .. getWeaponNameFromID(L2_16) .. " / " .. getBodyPartName(L3_17))
end)
addEvent("sendInfoToKiller", true)
addEventHandler("sendInfoToKiller", localPlayer, function(A0_19)
  local L1_20, L2_21, L3_22, L4_23
  L1_20 = A0_19[1]
  L2_21 = A0_19[2]
  L3_22 = A0_19[3]
  L4_23 = "#You killed "
  L4_23 = L4_23 .. removeHEXFromString(L1_20) .. " / " .. getWeaponNameFromID(L3_22) .. " / " .. getBodyPartName(L2_21)
  if isTimer(_UPVALUE0_[2]) then
    killTimer(_UPVALUE0_[2])
    _UPVALUE0_[2] = nil
  end
  guiSetText(_UPVALUE1_.label[2], L4_23)
  guiSetText(_UPVALUE1_.label[4], L4_23)
  hideGuiElement(2, true)
  _UPVALUE0_[2] = setTimer(hideGuiElement, 8000, 1, 2, false, 4)
  --outputConsole("[[ damagescript LOG ]]: #You killed " .. removeHEXFromString(L1_20) .. " / " .. getWeaponNameFromID(L3_22) .. " / " .. getBodyPartName(L2_21))
end)
addEvent("sendInfoToSource", true)
addEventHandler("sendInfoToSource", localPlayer, function(A0_24)
  local L1_25, L2_26, L3_27, L4_28
  L1_25 = A0_24[1]
  L2_26 = A0_24[2]
  L3_27 = A0_24[3]
  L4_28 = "#You killed by "
  L4_28 = L4_28 .. removeHEXFromString(L1_25) .. " / " .. getWeaponNameFromID(L3_27) .. " / " .. getBodyPartName(L2_26)
  if isTimer(_UPVALUE0_[1]) then
    killTimer(_UPVALUE0_[1])
    _UPVALUE0_[1] = nil
  end
  guiSetText(_UPVALUE1_.label[1], L4_28)
  guiSetText(_UPVALUE1_.label[3], L4_28)
  hideGuiElement(1, true)
  _UPVALUE0_[1] = setTimer(hideGuiElement, 8000, 1, 1, false, 3)
  --outputConsole("[[ damagescript LOG ]]: #You killed by " .. removeHEXFromString(L1_25) .. " / " .. getWeaponNameFromID(L3_27) .. " / " .. getBodyPartName(L2_26))
end)
addEventHandler("onClientPlayerSpawn", localPlayer, function()
  guiSetText(_UPVALUE0_.label[1], "")
  guiSetText(_UPVALUE0_.label[2], "")
  guiSetText(_UPVALUE0_.label[3], "")
  guiSetText(_UPVALUE0_.label[4], "")
end)
