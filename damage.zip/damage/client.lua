local L0_0
L0_0 = {
  {1, 2},
  {1, 2},
  {
    {1, 2},
    {
      {1, 2},
      {1, 2},
      {1, 2},
      {
        {1, 2},
        {1, 2},
        {1, 2},
        {
          {
            {
              {1, 2}
            }
          }
        }
      }
    },
    {1, 2},
    {1, 2}
  },
  {1, 2}
}
L0_0 = nil
addEventHandler("onPlayerWasted", root, function(A0_1, A1_2, A2_3, A3_4)
  if A1_2 and A1_2 ~= source then
    triggerClientEvent(source, "sendInfoToSource", source, {
      getPlayerName(A1_2),
      A3_4,
      A2_3
    })
    triggerClientEvent(A1_2, "sendInfoToKiller", A1_2, {
      getPlayerName(source),
      A3_4,
      A2_3
    })
  end
end)
addEventHandler("onPlayerDamage", root, function(A0_5, A1_6, A2_7, A3_8)
  if A0_5 and A0_5 ~= source then
    if math.floor(A3_8) == 0 then
      return
    end
    triggerClientEvent(source, "sendDmgToSource", source, {
      getPlayerName(A0_5),
      A1_6,
      A2_7
    })
    triggerClientEvent(A0_5, "sendDmgToAttacker", A0_5, {
      A3_8,
      getPlayerName(source),
      A1_6,
      A2_7,
      getElementHealth(source) + getPedArmor(source)
    })
  end
end)
addEventHandler("customEvent:OnPlayerDead", root, function(A0_9, A1_10, A2_11, A3_12, A4_13)
  if A1_10 and A1_10 ~= A0_9 then
    triggerClientEvent(A0_9, "sendInfoToSource", A0_9, {
      getPlayerName(A1_10),
      A3_12,
      A2_11
    })
    triggerClientEvent(A1_10, "sendInfoToKiller", A1_10, {
      getPlayerName(A0_9),
      A3_12,
      A2_11
    })
  end
end)
addEventHandler("customEvent:OnPlayerDamage", root, function(A0_14, A1_15, A2_16, A3_17, A4_18)
  if A1_15 and A1_15 ~= A0_14 then
    triggerClientEvent(A0_14, "sendDmgToSource", A0_14, {
      getPlayerName(A1_15),
      A2_16,
      A3_17
    })
    triggerClientEvent(A1_15, "sendDmgToAttacker", A1_15, {
      A4_18,
      getPlayerName(A0_14),
      A2_16,
      A3_17,
      getElementHealth(A0_14) + getPedArmor(A0_14)
    })
  end
end)
